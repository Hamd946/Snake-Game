//============================================================================
// Name        :Snake
// Author      :Hamd-Ul-Haq
// Roll#       :23I-0081
// Copyright   :(c) Reserved for FAST NUCES
// Description : 2 much snakes
//============================================================================
#ifndef TETRIS_CPP_
#define TETRIS_CPP_
#include "util.h"
#include <iostream>
#include<cstdlib>
#include<ctime>
#include<string>
#include<sys/wait.h>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<sstream>
#include<cmath>
#include<time.h>      
using namespace std;


int a3=188,b3=192,F1[5],F2[5],temp3,counter=0,H1,H2,H3,H4,H5,Score=0; // head of snake=a3,b3
int snakex[300]={a3+7, a3+22};
int snakey[300]={b3, b3};
int snakeLength=2;
bool L=false,R=false,U=false,D=false;//Left,Right,Up,Down
bool food=true;
bool hurdle=true;



void SetCanvasSize(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
    glMatrixMode( GL_MODELVIEW);
    glLoadIdentity();
}


double startx=320,starty=400;

void Display(){
 
 	srand((int)(time(NULL)));
    
        glClearColor(95.0/255.0/*Red Component*/, 185.0/255.0/*Green Component*/,
        0/*Blue Component*/, 1 /*Alpha component*/);// Red==Green==Blue==1 --> White Colour
        glClear(GL_COLOR_BUFFER_BIT);   //Update the colors
        
        //Drawing Foods
        if(food==true){
    		for(int counter=0;counter<5;counter++){
        		if(abs(a3-F1[counter])<=7 && abs(b3-F2[counter])<=7){
            			snakeLength++;
             			F1[counter]=(2+(rand()%34))*15+1;
    				F2[counter]=(4+(rand()%34))*15+5;
    				DrawSquare(F1[counter], F2[counter], 15, colors[YELLOW]);
    				Score+=5;
        			}
        		else if (F1[counter] != F1[temp3] && F2[counter] != F2[temp3] && F1[counter] != a3 && F2[counter] != b3 && F1[counter] - F1[temp3] != F2[counter] - F2[temp3] && F1[counter] != H1 && F1[counter] != H2 && F1[counter] != H3 && F1[counter] != H4 && F2[counter] != H1 && F2[counter] != H2 && F2[counter] != H3 && F2[counter] != H4) {
            		
            			DrawSquare(F1[counter], F2[counter], 15, colors[YELLOW]);
            			temp3 = counter;
        		}
    		}
	}
	//Drawing Hurdles
        if(hurdle==true){
        	for(int counter=0;counter<1;counter++){
        		if(abs(a3-H1) <=7  && b3<= H4 && b3>=H2){//Conditions for hurdles
        			sleep(1);
        			exit(1);
        		}
        		else if(abs(a3-H1)<=7 && b3<=H2 && b3>=H4){
        			sleep(1);
        			exit(1);
        		}
        		else if(abs(b3-H3)<=5 && H2<=a3 && a3<=H4){
        			sleep(1);
        			exit(1);
        		}
        		else if(abs(b3-H3)<=5 && H4<=a3 && a3<=H2){
        			sleep(1);
        			exit(1);
        		}
        		else{	
            			DrawLine(H1,H2,H1,H4,H5,colors[RED]);
             			DrawLine(H4,H3,H2,H3,H5,colors[RED]);
        		}
        	}
    	}

    
    //drawing snakes
    
    for(int i=0;i<snakeLength;i++){
        DrawSquare(snakex[i]-8, snakey[i]-6, 15, colors[BLACK]);
        	if (abs(a3-F1[i])<=7 && abs(b3-F2[i])<=7){ //Condition for snake eating food
			F1[counter]= (2+(rand()%34))*15+1;
    			F2[counter]=(4+(rand()%34))*15+5;
    			DrawSquare(F1[counter], F2[counter], 15, colors[YELLOW]);
    			snakeLength++;
    			Score+=5;
    		}
    		//Snake Collision With Itself Condition
    		if(a3==snakex[i] && b3==snakey[i] && i>3){
    			sleep(1);
    			exit(1);
    		}
    }
    
    
    if (Score<25){//Conditions For Score
    	DrawString(500, 620, "Score="+to_string(Score), colors[BLACK]);
    }
    else if(25<=Score && Score<50){
    	DrawString(500, 620, "Score="+to_string(Score), colors[BLUE]);
    }
    else if(50<=Score && Score<75){
    	DrawString(500, 620, "Score="+to_string(Score), colors[GREEN]);
    }
    else if(75<=Score && Score<100){
    	DrawString(500, 620, "Score="+to_string(Score), colors[YELLOW]);
    }
    else if(100<=Score && Score<150){
    	DrawString(500, 620, "Score="+to_string(Score), colors[ORANGE]);
    }
    else if(150<=Score){
    	DrawString(500, 620, "Score="+to_string(Score), colors[RED]);
    }
    if(Score<25){
    	DrawString( 30, 620, "Press Esc To Exit", colors[BLACK]);
    }
    else if(25<=Score && Score<50){
    	DrawString( 30, 620, "Press Esc To Exit", colors[BLUE]);
    }
    else if(50<=Score && Score<75){
    	DrawString( 30, 620, "Press Esc To Exit", colors[GREEN]);
    }
    else if(75<=Score && Score<100){
 	DrawString( 30, 620, "Press Esc To Exit", colors[YELLOW]);
    }
    else if(100<=Score && Score<150){
       DrawString( 30, 620, "Press Esc To Exit", colors[ORANGE]);
    }
    else if(150<=Score){
       DrawString( 30, 620, "Press Esc To Exit", colors[RED]);
    }
    
    DrawCircle( a3 , b3 , 7 , colors[BLACK]); // Head Of Snake
																		
																	
    
   //GRID 
    
    DrawLine( 585 , 50 ,  585 , 590 , 2 , colors[BLACK] ); 
    DrawLine( 30 , 590 ,  585 , 590 , 2 , colors[BLACK] );
    DrawLine( 30 , 50 ,  30 , 590 , 2 , colors[BLACK] );
    DrawLine( 30 , 50 ,  585 , 50 , 2 , colors[BLACK] );
    for(int i=45;i<=580;i+=15){
    	DrawLine( i , 50 ,  i , 590 , 2 , colors[GREEN] );
    }
    for(int j=65;j<=580;j+=15){
    	DrawLine( 30 , j ,  585 , j , 2 , colors[GREEN] );
    }

 

  
     
   glutSwapBuffers(); 
}


void NonPrintableKeys(int key, int x, int y) {

    int snakeHeadX=a3, snakeHeadY=b3;
    //Snake Movement
    if(key==GLUT_KEY_LEFT){
    	if(!(R)){

		L=true;
		U=false;
		D=false;
		
		a3-=15;
	}							
    } 
    else if(key==GLUT_KEY_RIGHT){
    	if(!(L)){
    		R=true;
    		U=false;
    		D=false;
    		
    		a3+=15;
	}
    } 
    else if(key==GLUT_KEY_UP ){
    	if(!(D)){
        	U=true;
        	R=false;
        	L=false;
        	
        	b3+=15;

        }
    }
    else if(key==GLUT_KEY_DOWN ){
       if(!(U)){
		D=true;
		R=false;
		L=false;
		
		b3-=15;
	}

    }
    
    for (int i=0; i<snakeLength; i++) {
        int temp1=snakex[i];
        int temp2=snakey[i];
        snakex[i]=snakeHeadX;
        snakey[i]=snakeHeadY;
        snakeHeadX=temp1;
        snakeHeadY=temp2;
    }

     glutPostRedisplay();

}


void PrintableKeys(unsigned char key, int x, int y) {
    
    if (key == KEY_ESC) {
        exit(1); 
    }
    if (key == 'R' || key=='r') {
    }
    
    else if (int(key) == 13)
    {  
	}
    
    glutPostRedisplay();
}

void timer2 (int m) {
    int snakeHeadX=a3, snakeHeadY=b3;
    //Snake Movement2
        if(U && b3<=575){
        	b3+=15;
        }
        else if(U && b3>575){
        	b3=35;
        	b3+=22;
        }
        
	if(D && b3>=60){
		b3-=15;
	}
	else if(D && b3<60){
		b3=603;
		b3-=22;
	}
	if(L && a3>=50){
		a3-=15;
	}
	else if(L && a3<50){
		a3=600;
		a3-=22;
	}
	if(R && a3<=575){
		a3+=15;
	}
	else if(R && a3>575){
		a3=20;
		a3+=18;
	}
	
    for(int i=0; i<snakeLength;i++){
        int temp1=snakex[i];
        int temp2=snakey[i];
        snakex[i]=snakeHeadX;
        snakey[i]=snakeHeadY;
        snakeHeadX=temp1;
        snakeHeadY=temp2;
    }

    glutPostRedisplay();
    glutTimerFunc(1000.0 / FPS, timer2, 0);
}

void Timer(int m){
    static int time=0;
   
    //Food Generation2
    
    glutPostRedisplay();

    for(int counter=0;counter<5;counter++){
    	F1[counter]= (2+(rand()%34))*15+1;
    	F2[counter]=(4+(rand()%34))*15+5;
    }
    
    time+=1;
    
    if(time>0 && time<=75){
    	food=true;
    }
    else if(time>75){
    	food=false;
    	time=0;
    }
    
    

	
    glutPostRedisplay();
    glutTimerFunc(75000.0 / FPS, Timer, 0);

}
void timer3(int m){
    static int time2=0;
    
    glutPostRedisplay();
    
    //Hurdle Generation2

    for(int counter=0;counter<1;counter++){
    	H1= (2+(rand()%33))*15;
    	H2=(2+(rand()%33))*15;
        H3=(2+(rand()%33))*15;
        H4=(2+(rand()%33))*15;
        H5=(rand()%3)+5;
    }
    
    time2+=1;
    
    if(time2>0 && time2<=150){
    	hurdle=true;
    }
    else if(time2>150){
    	hurdle=false;
    	time2=0;
    }
    glutPostRedisplay();
    glutTimerFunc(150000.0 / FPS, timer3, 0);
}



int main(int argc, char*argv[]) {
    
    int width = 650, height = 650; 
    InitRandomizer(); 
    glutInit(&argc, argv); 

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); 
    glutInitWindowPosition(50, 50); 
    glutInitWindowSize(width, height); 
    glutCreateWindow("PF's Snake Game"); 
    SetCanvasSize(width, height); 
    glutDisplayFunc(Display); 
    glutSpecialFunc(NonPrintableKeys); 
    glutKeyboardFunc(PrintableKeys); 
    glutTimerFunc(5.0 / FPS, Timer, 0);
    glutTimerFunc(5.0 / FPS, timer2, 0);
    glutTimerFunc(5.0 / FPS, timer3, 0);

    glutMainLoop();


    return 1;
    }
#endif /* Snake Game */




   
   
    

